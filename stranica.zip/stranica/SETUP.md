# Koločaj Bus - Web Stranica

Dobrodošli na web stranicu Koločaj Bus-a!

## ✅ Što je urađeno:

1. **Preimenovana firma** - Sada je sve pod imenom "Koločaj Bus"
2. **Dinamički izleti** - 6 izleta sa detaljima, cijenama i vrstama plaćanja
3. **Vrste plaćanja** - Za svaki izlet su dostupne opcije:
   - Gotovina pri dolasku
   - Bankni transfer
   - Kreditna/Debitna kartica
   - Obročna plaćanja

4. **Forma za rezervaciju** - Sa svim potrebnim poljima na jednoj stranici

## 📸 Kako dodati slike:

### Opcija 1: Koristi URL-ove
U datoteci `script.js`, zamijeni putanje slika sa web URL-ima. Npr:
```javascript
image: 'https://example.com/sarajevo.jpg'
```

### Opcija 2: Lokalne slike
1. Kreiraj slike (500x300px je idealna rezolucija)
2. Spremi ih u `assets/` folder sa sljedećim imenima:
   - `sarajevo.jpg` - Sarajevo
   - `venice.jpg` - Karneval u Veneciji
   - `moto.jpg` - Moto Bike Expo
   - `prague.jpg` - Prag
   - `flowers.jpg` - Sajam cvijeća
   - `split.jpg` - Split

3. Ako nema slike, prikazat će se atraktivne boje sa emojiima

## 🎨 Edukacija za izmjene:

### Dodaj novi izlet
U `script.js`, u niz `trips`, dodaj novi objekt:
```javascript
{
  id: 7,
  name: 'Naziv izleta',
  description: 'Opis',
  price: '99',
  date: '01 Apr',
  image: 'assets/slika.jpg',
  payment: ['Gotovina pri dolasku', 'Kreditna kartica']
}
```

### Promijeni cijenu
U `script.js`, pronađi izlet i promijeni `price` vrijednost.

### Promijeni vrste plaćanja
U `script.js`, promijeni niz `payment` za željeni izlet.

## 🚀 Struktura stranice:

- **Header** - Logo sa navigacijom
- **Hero sekcija** - Welcome poruka sa CTA gumbom
- **Trenutni eventos** - Ažurirani događaji
- **Izleti** - Dinamički učitani izleti sa slikama i plaćanjima
- **Zašto izabrati Koločaj Bus** - 3 prednosti
- **Rezerviraj svoj izlet** - Forma sa svim poljima
- **Kontakt** - Kontaktni podaci
- **Footer** - Copyright i info

## 📞 Kontakt informacije:
- **Telefon:** +385 1 234 5678
- **Email:** info@kolocajbus.hr
- **Lokacija:** Vaš grad, Hrvatska

## 💡 Savjeti:
- Slike se prikazuju u kartama sa 160px visine
- Ako slika ne postoji, prikazat će se boja i emoji
- Forma validira sva obavezna polja
- Sve radi na jednoj stranici - nema linkanja na druge stranice

Sve je sprema za pokretanje! Sretno! 🚌
