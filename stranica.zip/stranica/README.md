# Putnička agencija — web stranica
# Putnička agencija — web stranica

Ovo je završena verzija jednostavnog responzivnog predloška za vašu putničku agenciju.

Kako pokrenuti lokalno:

```bash
cd stranica
python -m http.server 8000
# zatim otvorite http://localhost:8000/ u pregledniku
```

Što je uključeno:
- Responzivni naslov (hero), navigacija, sekcija destinacije, usluge, rezervacijski obrazac i događaji.
- Polirane stilizacije: tipografija, tipke, kartice, fokus stanja za forme.
- Poboljšana pristupačnost: skip-link, form aria-live za povratne poruke, bolja mobilna navigacija.

Slike:
- Trenutačno se koriste grafičke placeholdere (bez slika). Kad budete spremni, stavite stvarne slike u `assets/` s ovim imenima:
  - `assets/hero.jpg` (hero pozadina)
  - `assets/card1.jpg` (Mediteranske plaže)
  - `assets/card2.jpg` (Planinska avantura)
  - `assets/card3.jpg` (Europski gradovi)

Događaji:
- Dodana je sekcija `Događaji` s povezanim stavkama na izvorne stranice.

Sljedeći koraci (po želji):
- Dodati stvarne slike u `assets/` (mogu ih preuzeti s vaše Site123 stranice ako potvrdite).
- Povezati rezervacijski obrazac s backendom ili servisom za e-mail.
- Finalno testiranje i eventualno SEO/GDPR dorade.

Ako želite, mogu:
- preuzeti i postaviti slike iz vaše Site123 stranice u `assets/` (potvrdite),
- potpuno kopirati tekst i sekcije s Site123 stranice (potvrdite),
- ili pripremiti jednostavan backend za prikupljanje rezervacija.

Hvala — recite koji korak želite sljedeći.
