cd stranica
python -m http.server 8000
# then open http://localhost:8000/