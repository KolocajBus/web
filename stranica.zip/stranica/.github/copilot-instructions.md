# Koločaj Bus — Copilot Instructions

## Project Overview
**Koločaj Bus** is a responsive travel agency website built with vanilla HTML, CSS, and JavaScript. It showcases one-day excursions across Croatia and Europe with dynamic trip cards, booking forms, and multi-language support (currently Croatian).

**Tech Stack**: HTML5 • CSS3 • Vanilla JavaScript • Font Awesome icons • Google Fonts

## Architecture & Data Flow

### Single-Page Structure
- **[index.html](index.html)** - Main document with semantic sections:
  - Header (contact info, navigation, mobile toggle)
  - Hero section with stats
  - Trips section (dynamically populated)
  - Services/About sections
  - Booking form
  - FAQ and Newsletter
  - Footer

- **[script.js](script.js)** - **Core logic that drives the entire site**:
  - **Trips array** (lines 3-83): Central data structure with trip objects containing `id`, `name`, `description`, `price`, `duration`, `image`, `payment`, `included`
  - **Dynamic rendering** (lines 86-123): Generates trip cards and populates booking form select from trips array
  - **Mobile navigation** (lines 125-137): Toggles nav menu with `aria-expanded` for accessibility
  - **Form submission** (lines 139-179): Client-side validation, total price calculation, success/error messaging
  - **Helper functions**: `scrollToReservation()`, FAQ toggles, counter animations, newsletter form
  
- **[styles.css](styles.css)** - Professional design system:
  - **CSS Variables** (lines 1-27): Accent colors (`--accent: #1E5A96`), spacing, shadows, max-width container
  - **Responsive breakpoints**: Mobile-first with 768px+ tablet/desktop tweaks
  - **Semantic structure**: Class names align with HTML (`.site-header`, `.card`, `.trip-card`, etc.)

### Data-Driven Architecture
The trips array in `script.js` is the single source of truth. All trip information flows from this array:
1. Trip cards render from array data
2. Booking form options populate from array
3. Form submission calculates total price using trip price

## Critical Developer Workflows

### Running Locally
```bash
cd stranica
python -m http.server 8000
# Then open http://localhost:8000/
```

### Adding/Editing Trips
Edit the `trips` array in [script.js](script.js#L3-L83). Each trip object requires:
- `id` (unique number)
- `name`, `description`, `price`, `duration`, `date`
- `image` (path to assets file, e.g., `assets/plitvicka-jezera.jpg.png`)
- `payment` (array of payment method strings)
- `included` (array of what's included in the trip)

Images automatically hide via `onerror` if file missing. Fallback: CSS background colors + emoji are already defined.

### Managing Images
- Store images in `assets/` folder
- Current naming pattern: descriptive kebab-case with extensions (e.g., `plitvicka-jezera.jpg.png`)
- Recommended size: 500x300px
- If image fails to load, card displays colored background (CSS defines fallbacks per card index)

### Form Validation
Client-side validation in [script.js](script.js#L164-L168):
- Required fields: name, email, phone, trip, payment, date
- Success message displays for 6 seconds, then auto-clears
- No backend integration—currently displays confirmation on client

## Project-Specific Patterns

### Accessibility Conventions
- Skip-link at top of body (`<a class="skip-link" href="#main">`)
- Mobile nav button uses `aria-expanded` and `aria-controls` attributes
- Form validation error styling: `#fff3cd` (warning) vs `#d1fae5` (success)
- All interactive elements have clear focus states (defined in CSS)

### Class Naming & Structure
- **Layout**: `.container`, `.header-inner`, `.section`
- **Cards**: `.card`, `.trip-card` (can be extended with modifiers)
- **Utilities**: `.btn`, `.btn-primary`, `.small`, `.open` (for toggle states)
- **Sections**: Named by ID matching content (e.g., `#izleti` for trips, `#rezerviraj` for booking)

### Event Handling Patterns
- Use `addEventListener` consistently (no inline `onclick` except for trip card buttons)
- Mobile nav closes when viewport ≤ 768px and user clicks a link
- FAQ items mutually exclusive: opening one closes all others
- Counter animations trigger via `IntersectionObserver` when stats section enters viewport

### Language & Localization
Currently **Croatian only** (hr-HR). All labels, button text, and form fields in Croatian:
- Form field names: `name`, `email`, `phone`, `trip`, `payment`, `people`, `date`
- Placeholders and labels in Croatian
- If adding new languages: update all strings in HTML sections (hero, buttons, form labels)

## Integration Points & External Dependencies

### External Libraries
- **Google Fonts**: Inter (body), Playfair Display (headings)
- **Font Awesome 6.4.0** via CDN: Used for icons throughout (`fas fa-*` classes)
- **No build step or package.json**: Pure vanilla setup

### Form Submission (Currently Mock)
Currently shows success message without server submission. To integrate with backend:
1. Replace form submit handler in [script.js](script.js#L160) with fetch/XMLHttpRequest
2. Send FormData to backend endpoint
3. Handle response and error states

### Analytics / Tracking
No analytics currently configured. If adding: Consider adding tracking codes in `<head>` and event listeners on CTA buttons (e.g., "Rezerviraj" button).

## Common Customization Patterns

### Add New Trip
1. Push object to `trips` array in [script.js](script.js)
2. Provide image file in `assets/` and reference in `image` field
3. Reload page—card and form option auto-populate

### Change Color Scheme
All brand colors in [styles.css](styles.css#L3-L5):
- `--accent: #1E5A96` (primary blue)
- `--accent-light`, `--accent-dark` (variants)
- Update variables and CSS regenerates throughout

### Extend FAQ or Services
- FAQ items: Edit HTML structure in `<section id="faq">` with `.faq-item` and `.faq-question` classes
- Services: Add new content blocks in `<section id="usluge">`
- JavaScript already handles FAQ toggle logic—no code change needed

## Files Quick Reference
| File | Purpose | Key Sections |
|------|---------|--------------|
| [index.html](index.html) | Structure & semantic markup | Sections by ID: hero, izleti, rezerviraj, faq, kontakt |
| [script.js](script.js) | All interactivity & data | Trips array, form handling, mobile nav, FAQ toggles |
| [styles.css](styles.css) | Design system & layout | CSS variables, responsive breakpoints, component classes |
| [SETUP.md](SETUP.md) | Setup & image instructions | How to add local images and edit trips |
