<?php
// Spremi email iz newsletter forme u CSV
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = isset($_POST['newsletter_email']) ? trim($_POST['newsletter_email']) : '';
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $file = fopen('newsletter.csv', 'a');
        fputcsv($file, [date('Y-m-d H:i:s'), $email]);
        fclose($file);
        echo 'Hvala na prijavi!';
    } else {
        echo 'Neispravna email adresa.';
    }
    exit;
}
?>