<?php
// Spremi podatke iz forme u CSV
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        date('Y-m-d H:i:s'),
        $_POST['name'] ?? '',
        $_POST['email'] ?? '',
        $_POST['phone'] ?? '',
        $_POST['trip'] ?? '',
        $_POST['people'] ?? '',
        $_POST['departure'] ?? '',
        $_POST['payment'] ?? '',
        $_POST['date'] ?? ''
    ];
    $file = fopen('rezervacije.csv', 'a');
    fputcsv($file, $data);
    fclose($file);
    echo 'Rezervacija je zaprimljena!';
    exit;
}
?>