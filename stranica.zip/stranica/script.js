document.addEventListener('DOMContentLoaded',function(){
  // Jednodnevni izleti sa atraktivnim cijenama
  const trips = [
    {
      id: 1,
      name: 'Plitvička Jezera',
      description: 'UNESCO svjetska baština - 16 kristalno čistih jezera sa vodopadima',
      price: '25',
      duration: '1 dan',
      date: 'Tijekom godine',
      image: 'assets/plitvicka-jezera.jpg.png',
      payment: ['Gotovina pri dolasku', 'Kartična plaćanja'],
      included: ['Autobus prijevoz', 'Vodiči', 'Obilazak jezera']
    },
    {
      id: 2,
      name: 'Nacionalni Park Krka',
      description: 'Spektakularna priroda sa vodopadi - najposjećeniji park u Hrvatskoj',
      price: '60',
      duration: '1 dan',
      date: 'Cijele godine',
      image: 'assets/nacionalni-park-krka.jpg.png',
      payment: ['Gotovina pri dolasku', 'Bankni transfer', 'Kartična plaćanja'],
      included: ['Autobus prijevoz', 'Vodiči']
    },
    {
      id: 3,
      name: 'Nacionalni Park Brijuni',
      description: 'Otočje sa bogatom prirodom, rimskim ruševinama i divljim životinjama',
      price: '55',
      duration: '1 dan',
      date: 'Tijekom godine',
      image: 'assets/nacionalni-park-brijuni.jpg.png',
      payment: ['Gotovina pri dolasku', 'Kartična plaćanja', 'Obročna plaćanja'],
      included: ['Autobus prijevoz', 'Vodiči', 'Obilazak otočja']
    },
    {
      id: 4,
      name: 'Karneval u Veneciji',
      description: 'Najpoznatiji karneval na svijetu - maske, kostimi i magija',
      price: '60',
      duration: '1 dan',
      date: 'Veljača (dan od dana)',
      image: 'assets/venecija.jpg.png',
      
      payment: ['Gotovina pri dolasku', 'Bankni transfer', 'Kartična plaćanja'],
      included: ['Autobus prijevoz', 'Vodiči']
    },
    {
      id: 5,
      name: 'Sajam Cvijeća Pordenone',
      description: 'Najveći sajam cvijeća i raznovrsnih gredica u Europi',
      price: '60',
      duration: '1 dan',
      date: 'Ožujak',
      image: 'assets/sajam-cvijeća-jpg.jpeg',
      payment: ['Gotovina pri dolasku', 'Kartična plaćanja'],
      included: ['Autobus prijevoz', 'Ulaznica sajma', 'Vodiči', ]
    },
    {
      id: 6,
      name: 'Riječki Karneval',
      description: 'Najveći karneval u Sjevernoj Europi - muzika, ples i maske',
      price: '35',
      duration: '1 dan',
      date: 'Veljača (dan od dana)',
      image: 'assets/riječki-karneval.jpg.png',
      payment: ['Gotovina pri dolasku', 'Kartična plaćanja'],
      included: ['Autobus prijevoz', 'Doživljaj']
    },
    {
      id: 7,
      name: 'Valentinovo - Bled i Ljubljana',
      description: 'Romantična putovanja kroz slovensko jezero Bled i lijepe trgovine Ljubljana',
      price: '40',
      duration: '1 dan',
      date: 'Veljača 14',
      image: 'assets/bled-ljubljana.jpg.png',
      payment: ['Gotovina pri dolasku', 'Bankni transfer', 'Kartična plaćanja'],
      included: ['Autobus prijevoz', , 'Obilazak Ljubljane', ]
    }
  ];

  // ===== CAROUSEL ROTACIJE AUTOBUSA =====
  const carouselSlides = document.querySelectorAll('.carousel-slide');
  let currentSlide = 0;

  function showSlide(n) {
    carouselSlides.forEach(slide => slide.classList.remove('active'));
    currentSlide = (n + carouselSlides.length) % carouselSlides.length;
    carouselSlides[currentSlide].classList.add('active');
  }

  function nextSlide() {
    showSlide(currentSlide + 1);
  }

  // Pokaži prvu sliku odmah
  if (carouselSlides.length > 0) {
    showSlide(0);
    // Rotira slike svakih 3 sekunde
    setInterval(nextSlide, 3000);
  }

  // ===== UČITAJ IZLETE =====
  const tripsList = document.getElementById('trips-list');
  const tripSelect = document.getElementById('trip-select');

  trips.forEach(trip => {
    // Kreiraj karticu za izlet
    const card = document.createElement('article');
    card.className = 'card trip-card';
    
    const imgPath = trip.image || 'assets/default.jpg';
    const paymentList = trip.payment.map(p => `<li>${p}</li>`).join('');
    const includedList = trip.included ? trip.included.map(i => `<li>${i}</li>`).join('') : '';
    
    card.innerHTML = `
      <div class="card-media">
        <img src="${imgPath}" alt="${trip.name}" onerror="this.style.display='none'">
      </div>
      <h3>${trip.name}</h3>
      <p>${trip.description}</p>
      <div class="trip-duration">⏱️ ${trip.duration}</div>
      <div class="trip-price">${trip.price}€ po osobi</div>
      <div class="trip-details">
        <strong>U cijeni je uključeno:</strong>
        <ul>
          ${includedList}
        </ul>
      </div>
      <div class="trip-details">
        <strong>Načini plaćanja:</strong>
        <ul>
          ${paymentList}
        </ul>
      </div>
      <button class="btn btn-primary" style="margin:1rem" onclick="scrollToReservation('${trip.id}')"><i class="fas fa-calendar-plus"></i> Rezerviraj Sada</button>
    `;
    
    tripsList.appendChild(card);

    // Dodaj u select za rezervaciju
    const option = document.createElement('option');
    option.value = trip.id;
    option.textContent = `${trip.name} - ${trip.price}€ (${trip.duration})`;
    tripSelect.appendChild(option);
  });

  // Mobilna navigacija
  const navToggle=document.getElementById('nav-toggle');
  const nav=document.getElementById('main-nav');
  navToggle.addEventListener('click',()=>{
    const expanded = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', String(!expanded));
    nav.classList.toggle('open');
  });
  
  // Zatvori mobilni meni kada se klikne na link
  const navLinks = nav.querySelectorAll('a');
  navLinks.forEach(link => link.addEventListener('click', ()=>{
    if(window.innerWidth <= 768){
      nav.classList.remove('open');
      navToggle.setAttribute('aria-expanded','false');
    }
  }));

  // Forma za rezervaciju
  const form=document.getElementById('booking-form');
  const result=document.getElementById('booking-result');
  
  form.addEventListener('submit',function(e){
    e.preventDefault();
    const data=new FormData(form);
    const name=data.get('name').trim();
    const email=data.get('email').trim();
    const phone=data.get('phone').trim();
    const trip=data.get('trip');
    const payment=data.get('payment');
    const people=data.get('people');
    const date=data.get('date');
    
    if(!name||!email||!phone||!trip||!payment||!date){
      result.innerHTML='<i class="fas fa-exclamation-circle"></i> Molim ispunite sva obavezna polja.';
      result.style.background='#fff3cd';
      result.style.borderLeftColor='#ffc107';
      result.style.color='#333';
      return;
    }
    
    // Pronađi odabrani izlet
    const selectedTrip = trips.find(t => t.id == trip);
    const totalPrice = selectedTrip.price * people;
    
    // Pripremi podatke za slanje
    const formData = new FormData();
    formData.append('name', name);
    formData.append('email', email);
    formData.append('phone', phone);
    formData.append('trip', selectedTrip.name);
    formData.append('trip_id', trip);
    formData.append('people', people);
    formData.append('date', date);
    formData.append('total_price', totalPrice + '€');
    formData.append('payment_method', payment);
    formData.append('submission_date', new Date().toLocaleString('hr-HR'));
    
    // Pošalji na Formspree
    fetch('https://formspree.io/f/YOUR_FORM_ID', {
      method: 'POST',
      body: formData
    })
    .then(response => {
      if(response.ok){
        result.innerHTML = `<i class="fas fa-check-circle"></i> <strong>Hvala ${name}!</strong> Vaša rezervacija je uspješno poslana!<br>
          <small>Potvrdnica je poslana na ${email}</small>`;
        result.style.background='#d1fae5';
        result.style.borderLeftColor='#10b981';
        result.style.color='#065f46';
        form.reset();
      } else {
        throw new Error('Greška pri slanju');
      }
    })
    .catch(error => {
      // Ako slanje na Formspree ne radi, prikaži barem lokalnu poruku
      result.innerHTML = `<i class="fas fa-check-circle"></i> <strong>Hvala ${name}!</strong> Vaša rezervacija je primljena.<br>
        <small>Izlet: <strong>${selectedTrip.name}</strong> | Osobe: <strong>${people}</strong> | Cijena: <strong>${totalPrice}€</strong></small>`;
      result.style.background='#d1fae5';
      result.style.borderLeftColor='#10b981';
      result.style.color='#065f46';
      console.log('Booking data:', {name, email, phone, trip: selectedTrip.name, people, date, totalPrice, payment});
      form.reset();
    });
    
    // Automatski očisti poruku nakon 6 sekundi
    setTimeout(()=>{
      result.innerHTML='';
    }, 6000);
  });
});

// Funkcija za preskakanje na rezervaciju
function scrollToReservation(tripId) {
  document.getElementById('trip-select').value = tripId;
  document.getElementById('rezerviraj').scrollIntoView({ behavior: 'smooth' });
}

// FAQ Toggles
document.addEventListener('DOMContentLoaded', function() {
  const faqQuestions = document.querySelectorAll('.faq-question');
  
  faqQuestions.forEach(question => {
    question.addEventListener('click', function() {
      const faqItem = this.closest('.faq-item');
      const isOpen = faqItem.classList.contains('open');
      
      // Zatvori sve ostale FAQ stavke
      document.querySelectorAll('.faq-item.open').forEach(item => {
        if (item !== faqItem) {
          item.classList.remove('open');
        }
      });
      
      // Toggle trenutnog
      faqItem.classList.toggle('open');
    });
  });

  // Newsletter form
  const newsletterForm = document.getElementById('newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const email = this.querySelector('input[type="email"]').value;
      const message = document.getElementById('newsletter-message');
      
      // Simulacija slanja
      message.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Pretplaćujem se...';
      
      setTimeout(() => {
        message.innerHTML = '<i class="fas fa-check-circle"></i> Hvala! Provjeri svoju email adresu.';
        this.reset();
        
        setTimeout(() => {
          message.innerHTML = '';
        }, 4000);
      }, 1500);
    });
  }

  // Animirani brojači
  function animateCounters() {
    const counters = document.querySelectorAll('.stat strong');
    
    counters.forEach(counter => {
      const target = counter.innerText;
      const isDecimal = target.includes('/');
      const isCurrency = target.includes('+');
      
      if (isDecimal) {
        const parts = target.split('/');
        const finalNum = parseFloat(parts[0]);
        const finalDen = parts[1];
        let current = 0;
        const increment = finalNum / 30;
        
        const updateCounter = () => {
          current += increment;
          if (current < finalNum) {
            counter.innerText = current.toFixed(1) + '/' + finalDen;
            setTimeout(updateCounter, 30);
          } else {
            counter.innerText = target;
          }
        };
        updateCounter();
      } else if (isCurrency) {
        const num = parseInt(target.replace(/\D/g, ''));
        let current = 0;
        const increment = Math.ceil(num / 30);
        
        const updateCounter = () => {
          current += increment;
          if (current < num) {
            counter.innerText = current + '+';
            setTimeout(updateCounter, 30);
          } else {
            counter.innerText = target;
          }
        };
        updateCounter();
            // Newsletter form - backend PHP preuzima obradu, JS nije potreban
